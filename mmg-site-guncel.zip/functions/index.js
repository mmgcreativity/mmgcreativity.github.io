/**
 * MMG Creativity — Blogger entegrasyonu (Cloud Functions v2)
 *
 * publishToBlogger: Sitede yayınlanmış bir blog yazısını Blogger blogunda yayınlar.
 *   - Sadece admin (users/{uid}.isAdmin == true) çağırabilir.
 *   - Yazı Firestore'da status:'published' olmalı.
 *   - Blogger'a gönderilince, yazıya bloggerPostId / bloggerUrl yazılır (tekrar gönderim engellenir).
 *
 * Gerekli secret'lar (firebase functions:secrets:set ... ile tanımlanır):
 *   BLOGGER_CLIENT_ID       — Google OAuth istemci kimliği
 *   BLOGGER_CLIENT_SECRET   — Google OAuth istemci sırrı
 *   BLOGGER_REFRESH_TOKEN   — blog sahibinin bir kerelik verdiği refresh token
 *   BLOGGER_BLOG_ID         — Blogger blogunun numeric blogId'si
 */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

const BLOGGER_CLIENT_ID = defineSecret("BLOGGER_CLIENT_ID");
const BLOGGER_CLIENT_SECRET = defineSecret("BLOGGER_CLIENT_SECRET");
const BLOGGER_REFRESH_TOKEN = defineSecret("BLOGGER_REFRESH_TOKEN");
const BLOGGER_BLOG_ID = defineSecret("BLOGGER_BLOG_ID");

// Sitedeki renderBlogBody ile aynı basit markdown → HTML dönüşümü,
// böylece Blogger'daki yazı da düzgün biçimlenir.
function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function mdToHtml(text) {
  return String(text || "")
    .split(/\n\s*\n/)
    .map((block) => {
      block = block.trim();
      if (!block) return "";
      if (block.startsWith("## ")) {
        return "<h2>" + escapeHtml(block.slice(3).trim()) + "</h2>";
      }
      const withBold = escapeHtml(block).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      return "<p>" + withBold.replace(/\n/g, "<br>") + "</p>";
    })
    .join("");
}

async function getAccessToken(clientId, clientSecret, refreshToken) {
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new HttpsError(
      "internal",
      "Google token alınamadı: " + (data.error_description || data.error || res.status)
    );
  }
  return data.access_token;
}

exports.publishToBlogger = onCall(
  {
    region: "us-central1",
    secrets: [BLOGGER_CLIENT_ID, BLOGGER_CLIENT_SECRET, BLOGGER_REFRESH_TOKEN, BLOGGER_BLOG_ID],
  },
  async (request) => {
    const uid = request.auth && request.auth.uid;
    if (!uid) {
      throw new HttpsError("unauthenticated", "Giriş yapmanız gerekiyor.");
    }

    // Yalnızca admin yayınlayabilsin
    const userSnap = await admin.firestore().doc("users/" + uid).get();
    if (!userSnap.exists || userSnap.data().isAdmin !== true) {
      throw new HttpsError("permission-denied", "Bu işlemi yalnızca yönetici yapabilir.");
    }

    const postId = request.data && request.data.postId;
    if (!postId) {
      throw new HttpsError("invalid-argument", "postId gerekli.");
    }

    const postRef = admin.firestore().doc("blogPosts/" + postId);
    const postSnap = await postRef.get();
    if (!postSnap.exists) {
      throw new HttpsError("not-found", "Yazı bulunamadı.");
    }
    const post = postSnap.data();
    if (post.status !== "published") {
      throw new HttpsError("failed-precondition", "Sadece yayınlanmış yazılar Blogger'a gönderilebilir.");
    }
    if (post.bloggerPostId) {
      // Zaten gönderilmiş — tekrar oluşturmayı engelle
      return { alreadyPublished: true, id: post.bloggerPostId, url: post.bloggerUrl || null };
    }

    const accessToken = await getAccessToken(
      BLOGGER_CLIENT_ID.value(),
      BLOGGER_CLIENT_SECRET.value(),
      BLOGGER_REFRESH_TOKEN.value()
    );

    const blogId = BLOGGER_BLOG_ID.value();
    const res = await fetch(
      "https://www.googleapis.com/blogger/v3/blogs/" + encodeURIComponent(blogId) + "/posts/",
      {
        method: "POST",
        headers: {
          Authorization: "Bearer " + accessToken,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          kind: "blogger#post",
          title: post.title || "Başlıksız",
          content: mdToHtml(post.content),
        }),
      }
    );
    const bp = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new HttpsError(
        "internal",
        "Blogger'a gönderilemedi: " + ((bp.error && bp.error.message) || res.status)
      );
    }

    await postRef.update({
      bloggerPostId: bp.id || null,
      bloggerUrl: bp.url || null,
      bloggerPublishedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { ok: true, id: bp.id || null, url: bp.url || null };
  }
);
